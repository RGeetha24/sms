<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Bulk SMS Portal with Twilio</h3>
    <form class="jumbotron" action='' method='post'>
        <?php echo csrf_field(); ?>
        <?php if($errors->any()): ?>
        <ul>
             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($error); ?> </li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if( session( 'success' ) ): ?>
            <?php echo e(session( 'success' )); ?>

        <?php endif; ?>

            <div class="form-group">
                <label for="exampleFormControlTextarea1">Phone numbers (seperate with a comma [,])</label>
                <input type='text' name='numbers' class="form-control"/>
            </div>

            <div class="form-group">
                <label for="exampleFormControlTextarea1">Message</label>
                <textarea class="form-control" id="exampleFormControlTextarea1" name='message' rows="3"></textarea>
            </div>

            <button class="btn btn-primary mt-3" type='submit'>Send!</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel9\testing\resources\views/bulksms.blade.php ENDPATH**/ ?>